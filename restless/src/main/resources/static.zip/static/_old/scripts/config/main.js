const LOCAL_STORAGE_LOGIN_TOKEN_NAME = "userid";
const ROOT_PATH = "http://localhost:8080";